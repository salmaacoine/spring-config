package com.example.microservicecommandes2.controller;

import com.example.microservicecommandes2.model.Commande;
import com.example.microservicecommandes2.service.CommandeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/commandes")
@CrossOrigin(origins = "*")
@Tag(name = "Commandes API", description = "API de gestion des commandes")
public class CommandeController {

    private final CommandeService service;

    @Autowired
    public CommandeController(CommandeService service) {
        this.service = service;
    }

    @GetMapping
    @Operation(summary = "Lister toutes les commandes")
    public List<Commande> getAllCommandes() {
        return service.findAll();
    }



    @GetMapping("/")
    public String home() {
        return "forward:/index.html";
    }

    @GetMapping("/dashboard")
    public String dashboard() {
        return "forward:/index.html";
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtenir une commande par ID")
    public ResponseEntity<Commande> getCommandeById(@PathVariable Long id) {
        return service.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    @Operation(summary = "Créer une nouvelle commande")
    public Commande createCommande(@RequestBody Commande commande) {
        return service.createCommandeWithProductVerification(commande);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Modifier une commande existante")
    public ResponseEntity<Commande> updateCommande(@PathVariable Long id, @RequestBody Commande commande) {
        return service.findById(id)
                .map(existing -> ResponseEntity.ok(service.update(id, commande)))
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Supprimer une commande")
    public ResponseEntity<Void> deleteCommande(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/produit/{produitId}")
    @Operation(summary = "Obtenir les commandes par produit")
    public List<Commande> getCommandesByProduit(@PathVariable Long produitId) {
        return service.findByProduitId(produitId);
    }

    @GetMapping("/recent")
    @Operation(summary = "Obtenir les commandes récentes")
    public List<Commande> getRecentCommandes(@RequestParam(defaultValue = "7") int jours) {
        return service.findLastDays(LocalDate.now().minusDays(jours));
    }

    @GetMapping("/produit-info/{produitId}")
    @Operation(summary = "Obtenir les informations d'un produit")
    public String getProduitInfo(@PathVariable Long produitId) {
        return service.getProduitInfo(produitId);
    }

    @GetMapping("/count")
    @Operation(summary = "Compter le nombre de commandes")
    public long getCommandesCount() {
        return service.count();
    }
}