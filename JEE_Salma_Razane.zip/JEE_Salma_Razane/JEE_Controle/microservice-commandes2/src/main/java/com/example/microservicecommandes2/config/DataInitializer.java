package com.example.microservicecommandes2.config;


import com.example.microservicecommandes2.model.Commande;
import com.example.microservicecommandes2.repository.CommandeRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initData(CommandeRepository commandeRepo) {
        return args -> {
            // Données de test pour Commandes
            commandeRepo.save(new Commande("Commande 1", 2, LocalDate.now(), 150.0, 1L));
            commandeRepo.save(new Commande("Commande 2", 1, LocalDate.now().minusDays(1), 75.5, 2L));
            commandeRepo.save(new Commande("Commande 3", 3, LocalDate.now().minusDays(3), 200.0, 1L));
        };
    }
}