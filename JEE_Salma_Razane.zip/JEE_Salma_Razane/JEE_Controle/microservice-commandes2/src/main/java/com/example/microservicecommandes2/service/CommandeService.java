package com.example.microservicecommandes2.service;


import com.example.microservicecommandes2.model.Commande;
import com.example.microservicecommandes2.repository.CommandeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class CommandeService {

    private final CommandeRepository repo;
    private final RestTemplate restTemplate;

    @Autowired
    public CommandeService(CommandeRepository repo, RestTemplate restTemplate) {
        this.repo = repo;
        this.restTemplate = restTemplate;
    }

    // CRUD Basique
    public Commande create(Commande c) {
        return repo.save(c);
    }

    public Optional<Commande> findById(Long id) {
        return repo.findById(id);
    }

    public List<Commande> findAll() {
        return repo.findAll();
    }

    public Commande update(Long id, Commande c) {
        c.setId(id);
        return repo.save(c);
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }

    // Méthodes personnalisées
    public List<Commande> findLastDays(LocalDate from) {
        return repo.findAllByDateAfter(from);
    }

    public long count() {
        return repo.count();
    }

    public List<Commande> findByProduitId(Long produitId) {
        return repo.findByIdProduit(produitId);
    }

    // Appel au microservice produits avec gestion d'erreur
    public String getProduitInfo(Long produitId) {
        try {
            String url = "http://microservice-produits/api/produits/" + produitId;
            return restTemplate.getForObject(url, String.class);
        } catch (Exception e) {
            return "Information produit non disponible - Service indisponible";
        }
    }

    // Création avec vérification du produit
    public Commande createCommandeWithProductVerification(Commande commande) {
        String produitInfo = getProduitInfo(commande.getIdProduit());
        if (produitInfo.contains("non disponible")) {
            // Mode dégradé : sauvegarde sans vérification
            commande.setDescription(commande.getDescription() + " [Créé sans vérification produit]");
        }
        return repo.save(commande);
    }
}