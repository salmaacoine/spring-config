package com.example.microservicecommandes2.health;



import com.example.microservicecommandes2.service.CommandeService;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

@Component("commandes")
public class CommandesHealthIndicator implements HealthIndicator {
    private final CommandeService service;

    public CommandesHealthIndicator(CommandeService service){
        this.service = service;
    }

    @Override
    public Health health() {
        long count = service.count();

        if (count > 0) {
            return Health.up()
                    .withDetail("commandesCount", count)
                    .withDetail("message", "Service des commandes opérationnel")
                    .build();
        } else {
            return Health.down()
                    .withDetail("commandesCount", count)
                    .withDetail("message", "Aucune commande dans la base de données")
                    .build();
        }
    }
}