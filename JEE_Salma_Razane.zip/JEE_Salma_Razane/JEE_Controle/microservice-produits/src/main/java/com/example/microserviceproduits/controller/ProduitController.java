package com.example.microserviceproduits.controller;

import com.example.microserviceproduits.model.Produit;
import com.example.microserviceproduits.service.ProduitService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/produits")
@Tag(name = "Produits API", description = "API de gestion des produits")
public class ProduitController {

    private final ProduitService service;

    @Autowired
    public ProduitController(ProduitService service) {
        this.service = service;
    }

    @GetMapping
    @Operation(summary = "Lister tous les produits")
    public List<Produit> getAllProduits() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtenir un produit par ID")
    public ResponseEntity<String> getProduitById(@PathVariable Long id) {
        return service.findById(id)
                .map(produit -> ResponseEntity.ok(produit.toString() + " - " + service.getServiceInfo()))
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    @Operation(summary = "Créer un nouveau produit")
    public Produit createProduit(@RequestBody Produit produit) {
        return service.create(produit);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Modifier un produit existant")
    public ResponseEntity<Produit> updateProduit(@PathVariable Long id, @RequestBody Produit produit) {
        return service.findById(id)
                .map(existing -> ResponseEntity.ok(service.update(id, produit)))
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Supprimer un produit")
    public ResponseEntity<Void> deleteProduit(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/count")
    @Operation(summary = "Compter le nombre de produits")
    public long getProduitsCount() {
        return service.count();
    }

    @GetMapping("/info")
    @Operation(summary = "Informations du service")
    public String getServiceInfo() {
        return service.getServiceInfo();
    }
}