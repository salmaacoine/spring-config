package com.example.microservicecommandes1.service;

import com.example.microservicecommandes1.model.Commande;
import com.example.microservicecommandes1.repository.CommandeRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class CommandeService {
    private final CommandeRepository repo;

    public CommandeService(CommandeRepository repo){ this.repo = repo; }

    // --- CRUD ---
    public Commande create(Commande c){ return repo.save(c); }
    public Optional<Commande> findById(Long id){ return repo.findById(id); }
    public List<Commande> findAll(){ return repo.findAll(); }
    public Commande update(Long id, Commande c){
        c.setId(id);
        return repo.save(c);
    }
    public void delete(Long id){ repo.deleteById(id); }

    // --- Logique Personnalisée ---
    public List<Commande> findLastDays(LocalDate from){ return repo.findAllByDateAfter(from); }
    public long count(){ return repo.count(); }
}