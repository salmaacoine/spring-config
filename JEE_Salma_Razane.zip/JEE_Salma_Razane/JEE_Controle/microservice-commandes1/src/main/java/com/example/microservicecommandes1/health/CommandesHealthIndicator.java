package com.example.microservicecommandes1.health;

import com.example.microservicecommandes1.service.CommandeService;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

@Component("commandes")
public class CommandesHealthIndicator implements HealthIndicator {
    private final CommandeService service;

    public CommandesHealthIndicator(CommandeService service){ this.service = service; }

    @Override
    public Health health() {
        long count = service.count();

        if (count > 0) {
            // Statut UP si des commandes existent
            return Health.up().withDetail("commandesCount", count).build();
        } else {
            // Statut DOWN si la collection est vide
            return Health.down().withDetail("commandesCount", count).build();
        }
    }
}
