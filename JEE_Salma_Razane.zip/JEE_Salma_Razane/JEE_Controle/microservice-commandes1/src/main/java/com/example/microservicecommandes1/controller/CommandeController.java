package com.example.microservicecommandes1.controller;

import com.example.microservicecommandes1.config.CommandesProperties;
import com.example.microservicecommandes1.model.Commande;
import com.example.microservicecommandes1.service.CommandeService;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RefreshScope
@RequestMapping("/api/commandes")
public class CommandeController {
    private final CommandeService service;
    private final CommandesProperties props;

    public CommandeController(CommandeService service, CommandesProperties props){
        this.service = service;
        this.props = props;
    }

    @GetMapping("/")
    public String index() {
        return "forward:/index.html";
    }
    // --- Opérations CRUD ---
    @GetMapping
    public List<Commande> all(){ return service.findAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<Commande> get(@PathVariable Long id){
        return service.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Commande create(@RequestBody Commande c){ return service.create(c); }

    @PutMapping("/{id}")
    public ResponseEntity<Commande> update(@PathVariable Long id, @RequestBody Commande c){
        return service.findById(id)
                .map(existing -> ResponseEntity.ok(service.update(id, c)))
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id){
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    // --- Endpoint utilisant la propriété centralisée (Point c) ---
    @GetMapping("/recent")
    public List<Commande> recent(){
        int jours = props.getCommandesLast();
        return service.findLastDays(LocalDate.now().minusDays(jours));
    }
}