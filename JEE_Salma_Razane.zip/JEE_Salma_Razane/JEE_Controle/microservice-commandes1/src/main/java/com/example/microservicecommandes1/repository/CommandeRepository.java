package com.example.microservicecommandes1.repository;

import com.example.microservicecommandes1.model.Commande;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;

public interface CommandeRepository extends JpaRepository<Commande, Long> {
    List<Commande> findAllByDateAfter(LocalDate from);
}