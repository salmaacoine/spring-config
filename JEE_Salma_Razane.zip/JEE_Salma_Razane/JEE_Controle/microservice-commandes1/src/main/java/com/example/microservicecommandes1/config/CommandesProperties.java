package com.example.microservicecommandes1.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

@Component
@RefreshScope
@ConfigurationProperties(prefix = "mes-config-ms")
public class CommandesProperties {
    // La propriété 'commandes-last' sera injectée ici depuis GitHub
    private int commandesLast = 10;

    public int getCommandesLast() { return commandesLast; }
    public void setCommandesLast(int commandesLast) { this.commandesLast = commandesLast; }
}