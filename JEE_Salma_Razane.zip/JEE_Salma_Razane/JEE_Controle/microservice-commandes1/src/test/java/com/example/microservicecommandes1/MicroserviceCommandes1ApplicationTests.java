package com.example.microservicecommandes1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceCommandes1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
