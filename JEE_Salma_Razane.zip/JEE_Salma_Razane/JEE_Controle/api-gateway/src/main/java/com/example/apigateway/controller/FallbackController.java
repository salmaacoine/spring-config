package com.example.apigateway.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/fallback")
public class FallbackController {

    @GetMapping("/commandes")
    public Map<String, Object> commandesFallback() {
        Map<String, Object> response = new HashMap<>();
        response.put("message", "Service Commandes temporairement indisponible");
        response.put("timestamp", java.time.LocalDateTime.now().toString());
        response.put("status", 503);
        return response;
    }

    @GetMapping("/produits")
    public Map<String, Object> produitsFallback() {
        Map<String, Object> response = new HashMap<>();
        response.put("message", "Service Produits temporairement indisponible");
        response.put("timestamp", java.time.LocalDateTime.now().toString());
        response.put("status", 503);
        return response;
    }
}